Crowd Dynamics in three goes: Go 2 lab kit

Install: pip install -r requirements.txt
Run any lab: python <file>.py
Each script prints the numbers quoted on its module page. All data are synthetic teaching data.
